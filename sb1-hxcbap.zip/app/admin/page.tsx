"use client"

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Bell, User } from 'lucide-react';

const mockOrders = [
  { id: 1, passengerName: 'John Doe', pickupLocation: '123 Main St', destination: '456 Elm St', status: 'Pending' },
  { id: 2, passengerName: 'Jane Smith', pickupLocation: '789 Oak Ave', destination: '321 Pine Rd', status: 'Completed' },
  { id: 3, passengerName: 'Bob Johnson', pickupLocation: '159 Maple Ln', destination: '753 Birch Blvd', status: 'Canceled' },
];

export default function AdminDashboard() {
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [filter, setFilter] = useState('All');

  const filteredOrders = filter === 'All' ? mockOrders : mockOrders.filter(order => order.status === filter);

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="flex justify-between items-center mb-8">
        <div className="text-2xl font-bold">TaxiBook Admin</div>
        <div className="flex items-center space-x-4">
          <Bell className="w-6 h-6" />
          <User className="w-6 h-6" />
        </div>
      </header>

      <div className="flex">
        <aside className="w-64 pr-8">
          <nav>
            <ul className="space-y-2">
              <li><a href="#" className="block p-2 hover:bg-gray-100 rounded">View Orders</a></li>
              <li><a href="#" className="block p-2 hover:bg-gray-100 rounded">Fleet Management</a></li>
              <li><a href="#" className="block p-2 hover:bg-gray-100 rounded">Reports</a></li>
              <li><a href="#" className="block p-2 hover:bg-gray-100 rounded">Settings</a></li>
            </ul>
          </nav>
        </aside>

        <main className="flex-1">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-2xl font-bold">Latest Orders</h1>
            <div className="space-x-2">
              <Button variant={filter === 'All' ? 'default' : 'outline'} onClick={() => setFilter('All')}>All</Button>
              <Button variant={filter === 'Pending' ? 'default' : 'outline'} onClick={() => setFilter('Pending')}>Pending</Button>
              <Button variant={filter === 'Completed' ? 'default' : 'outline'} onClick={() => setFilter('Completed')}>Completed</Button>
              <Button variant={filter === 'Canceled' ? 'default' : 'outline'} onClick={() => setFilter('Canceled')}>Canceled</Button>
            </div>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order Number</TableHead>
                <TableHead>Passenger Name</TableHead>
                <TableHead>Pickup Location</TableHead>
                <TableHead>Destination</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>{order.id}</TableCell>
                  <TableCell>{order.passengerName}</TableCell>
                  <TableCell>{order.pickupLocation}</TableCell>
                  <TableCell>{order.destination}</TableCell>
                  <TableCell>{order.status}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => setSelectedOrder(order)}>View Details</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {selectedOrder && (
            <div className="mt-8 p-4 border rounded-lg">
              <h2 className="text-xl font-semibold mb-4">Order Details</h2>
              <p><strong>Order Number:</strong> {selectedOrder.id}</p>
              <p><strong>Passenger Name:</strong> {selectedOrder.passengerName}</p>
              <p><strong>Pickup Location:</strong> {selectedOrder.pickupLocation}</p>
              <p><strong>Destination:</strong> {selectedOrder.destination}</p>
              <p><strong>Status:</strong> {selectedOrder.status}</p>
              <div className="mt-4 space-x-2">
                <Button variant="outline" size="sm">Change Status</Button>
                <Button variant="outline" size="sm">Contact Driver</Button>
                <Button variant="outline" size="sm">Contact Passenger</Button>
              </div>
            </div>
          )}
        </main>
      </div>

      <footer className="mt-12 text-center text-sm text-gray-600">
        <p>TaxiBook Admin v1.0 | Customer Service: admin@taxibook.com</p>
      </footer>
    </div>
  );
}