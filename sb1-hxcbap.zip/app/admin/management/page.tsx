"use client"

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Bell, User } from 'lucide-react';

const mockOrders = [
  { id: 1, passengerName: 'John Doe', pickupLocation: '123 Main St', destination: '456 Elm St', status: 'Pending' },
  { id: 2, passengerName: 'Jane Smith', pickupLocation: '789 Oak Ave', destination: '321 Pine Rd', status: 'Completed' },
  { id: 3, passengerName: 'Bob Johnson', pickupLocation: '159 Maple Ln', destination: '753 Birch Blvd', status: 'Canceled' },
];

export default function OrderManagement() {
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [filter, setFilter] = useState('All');
  const [newStatus, setNewStatus] = useState('');
  const [notes, setNotes] = useState('');

  const filteredOrders = filter === 'All' ? mockOrders : mockOrders.filter(order => order.status === filter);

  const handleStatusChange = () => {
    if (selectedOrder && newStatus) {
      // In a real application, you would update the order status in your backend here
      console.log(`Updating order ${selectedOrder.id} status to ${newStatus}`);
      setSelectedOrder({ ...selectedOrder, status: newStatus });
      setNewStatus('');
    }
  };

  const handleAddNotes = () => {
    if (selectedOrder && notes) {
      // In a real application, you would add these notes to the order in your backend
      console.log(`Adding notes to order ${selectedOrder.id}: ${notes}`);
      setNotes('');
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="flex justify-between items-center mb-8">
        <div className="text-2xl font-bold">TaxiBook Admin</div>
        <div className="flex items-center space-x-4">
          <Bell className="w-6 h-6" />
          <User className="w-6 h-6" />
        </div>
      </header>

      <div className="flex">
        <aside className="w-64 pr-8">
          <nav>
            <ul className="space-y-2">
              <li><a href="/admin" className="block p-2 hover:bg-gray-100 rounded">Dashboard</a></li>
              <li><a href="#" className="block p-2 bg-gray-100 rounded">Order Management</a></li>
              <li><a href="#" className="block p-2 hover:bg-gray-100 rounded">Fleet Management</a></li>
              <li><a href="#" className="block p-2 hover:bg-gray-100 rounded">Reports</a></li>
              <li><a href="#" className="block p-2 hover:bg-gray-100 rounded">Settings</a></li>
            </ul>
          </nav>
        </aside>

        <main className="flex-1">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-2xl font-bold">Order Management</h1>
            <div className="space-x-2">
              <Button variant={filter === 'All' ? 'default' : 'outline'} onClick={() => setFilter('All')}>All</Button>
              <Button variant={filter === 'Pending' ? 'default' : 'outline'} onClick={() => setFilter('Pending')}>Pending</Button>
              <Button variant={filter === 'Completed' ? 'default' : 'outline'} onClick={() => setFilter('Completed')}>Completed</Button>
              <Button variant={filter === 'Canceled' ? 'default' : 'outline'} onClick={() => setFilter('Canceled')}>Canceled</Button>
            </div>
          </div>

          <div className="flex space-x-4 mb-4">
            <div className="w-2/3">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order Number</TableHead>
                    <TableHead>Passenger Name</TableHead>
                    <TableHead>Pickup Location</TableHead>
                    <TableHead>Destination</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell>{order.id}</TableCell>
                      <TableCell>{order.passengerName}</TableCell>
                      <TableCell>{order.pickupLocation}</TableCell>
                      <TableCell>{order.destination}</TableCell>
                      <TableCell>{order.status}</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm" onClick={() => setSelectedOrder(order)}>Manage</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="w-1/3">
              {selectedOrder ? (
                <div className="border p-4 rounded-lg">
                  <h2 className="text-xl font-semibold mb-4">Manage Order #{selectedOrder.id}</h2>
                  <p><strong>Passenger:</strong> {selectedOrder.passengerName}</p>
                  <p><strong>Pickup:</strong> {selectedOrder.pickupLocation}</p>
                  <p><strong>Destination:</strong> {selectedOrder.destination}</p>
                  <p><strong>Current Status:</strong> {selectedOrder.status}</p>
                  
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700">Change Status</label>
                    <Select onValueChange={setNewStatus}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select new status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Pending">Pending</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                        <SelectItem value="Canceled">Canceled</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button className="mt-2 w-full" onClick={handleStatusChange}>Update Status</Button>
                  </div>

                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700">Add Notes</label>
                    <Textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Enter notes about this order"
                      rows={3}
                    />
                    <Button className="mt-2 w-full" onClick={handleAddNotes}>Add Notes</Button>
                  </div>
                </div>
              ) : (
                <div className="border p-4 rounded-lg text-center text-gray-500">
                  Select an order to manage
                </div>
              )}
            </div>
          </div>
        </main>
      </div>

      <footer className="mt-12 text-center text-sm text-gray-600">
        <p>TaxiBook Admin v1.0 | Customer Service: admin@taxibook.com</p>
      </footer>
    </div>
  );
}