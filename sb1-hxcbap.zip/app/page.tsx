"use client"

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Taxi } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="flex justify-between items-center mb-8">
        <div className="flex items-center">
          <Taxi className="w-8 h-8 mr-2" />
          <h1 className="text-3xl font-bold">TaxiBook</h1>
        </div>
        <nav>
          <Link href="/booking" passHref>
            <Button variant="outline" className="mr-2">Book a Ride</Button>
          </Link>
          <Link href="/admin" passHref>
            <Button variant="outline">Admin</Button>
          </Link>
        </nav>
      </header>

      <main>
        <section className="text-center py-12">
          <h2 className="text-4xl font-bold mb-4">Welcome to TaxiBook</h2>
          <p className="text-xl mb-8">Your reliable taxi booking service</p>
          <Link href="/booking" passHref>
            <Button size="lg">Book Now</Button>
          </Link>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-8 my-12">
          <div className="text-center">
            <h3 className="text-2xl font-semibold mb-2">Easy Booking</h3>
            <p>Book your ride with just a few clicks</p>
          </div>
          <div className="text-center">
            <h3 className="text-2xl font-semibold mb-2">Reliable Drivers</h3>
            <p>Our drivers are professional and punctual</p>
          </div>
          <div className="text-center">
            <h3 className="text-2xl font-semibold mb-2">24/7 Service</h3>
            <p>We're available round the clock for your convenience</p>
          </div>
        </section>
      </main>

      <footer className="text-center text-sm text-gray-600 mt-12">
        <p>&copy; 2023 TaxiBook. All rights reserved.</p>
      </footer>
    </div>
  )
}