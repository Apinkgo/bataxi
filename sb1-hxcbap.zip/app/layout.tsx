import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Online Taxi Booking',
  description: 'Book your taxi online',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        {children}
        <Toaster />
        <script dangerouslySetInnerHTML={{
          __html: `
            (function() {
              var attrs = ['__processed', 'bis_status', 'bis_frame_id'];
              attrs.forEach(function(attr) {
                var elements = document.querySelectorAll('[' + attr + ']');
                elements.forEach(function(el) {
                  el.removeAttribute(attr);
                });
              });
            })();
          `
        }} />
      </body>
    </html>
  )
}