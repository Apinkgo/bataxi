import Document, { Html, Head, Main, NextScript, DocumentContext } from 'next/document'

class MyDocument extends Document {
  static async getInitialProps(ctx: DocumentContext) {
    const initialProps = await Document.getInitialProps(ctx)
    return { ...initialProps }
  }

  render() {
    return (
      <Html lang="en">
        <Head />
        <body>
          <Main />
          <NextScript />
          <script dangerouslySetInnerHTML={{
            __html: `
              (function() {
                var attrs = [
                  '__processed_fd07b596-fc4c-4a48-b576-df37e01ee1c9__',
                  '__processed_999a42c0-cdf0-4b59-b7cf-35cb93ca829b__',
                  '__processed_4de117d6-cac8-420f-8862-f625ce61910e__',
                  '__processed_37a7fe4a-294c-498f-9277-d2fd8e3d954e__',
                  'data-hasqtip',
                  'bis_status',
                  'bis_frame_id'
                ];
                attrs.forEach(function(attr) {
                  if (document.body.hasAttribute(attr)) {
                    document.body.removeAttribute(attr);
                  }
                });
              })();
            `
          }} />
        </body>
      </Html>
    )
  }
}

export default MyDocument